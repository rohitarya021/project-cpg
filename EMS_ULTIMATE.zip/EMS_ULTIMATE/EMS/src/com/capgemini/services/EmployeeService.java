package com.capgemini.services;

import java.util.List;

import com.capgemini.entities.Employee;

public interface EmployeeService {
	
	void addEmployee(Employee emp);

	List<Employee> getAllEmployee();
	
	Employee getEmployeeById(int id);
	
	void updateEmployee(Employee emp);
	
	Employee getEmployeeByFirstName(String fname);
	
	Employee getEmployeeByLastName(String lname);
	
	/*	public List<Employee> showAllEmployees() ;
		
		public void modifyEmployee(Employee emp) ;
		
		public Employee searchEmployeeById(int id) ;
		
		public List<Employee> searchEmployeeByFirstName(String fname);
		
		public List<Employee> searchEmployeeByLasttName(String lname) ;
		
		public List<Employee> searchEmployeeByMartitalStatus(String marital);*/

}
