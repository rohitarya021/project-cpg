package com.capgemini.daos;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.Employee;
import com.capgemini.entities.GradeMaster;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	@PersistenceContext
	EntityManager entitymanager;

	/*
	 * This method of DAO will display all the employees
	 * 
	 * */
	@Override
	public List<Employee> getAllEmployee() {
		TypedQuery<Employee> query = entitymanager.createQuery("SELECT s FROM Employee s", Employee.class);
		return query.getResultList();
	}
	
/**
 * @return *****************************************************************************************/
	
	/*
	 * This method of DAO will add the employee to the DataBase
	 * 
	 * */
	@Override
	public int addEmployee(Employee emp) {

		entitymanager.persist(emp);
		entitymanager.flush();
		return emp.getEmp_Id();
		
	}
	
/******************************************************************************************/
	
	/*
	 * This method of DAO will fetch the Grades from the DataBase
	 * 
	 * */
	
	@Override
	public List<String> fetchGrades() {
		TypedQuery<GradeMaster> query = entitymanager.createQuery("SELECT g FROM GradeMaster g", GradeMaster.class);
		List<String> grades=new ArrayList<String>(); 
		for (GradeMaster grade : query.getResultList()) {
			grades.add(grade.getGrade_Code());
		}
		return grades;
	}
	
/*******************************************************************************************/
	/*
	 * This method of DAO will fetch the Employee from the DataBase using ID
	 * 
	 * */
	
	@Override
	public Employee getEmployeeById(int id) {
		Employee emp = new Employee();
		emp = entitymanager.find(Employee.class, id);
	
		return emp;
	}
	
	
	
	@Override
	public Employee getEmployeeByFirstName(String fname) {
		Employee emp = new Employee();
		
		emp = entitymanager.find(Employee.class, fname);
	  
		return emp;
		
	}

	
	
/*******************************************************************************************/
	/*
	 * This method of DAO will update the Employee from the DataBase using ID
	 * 
	 * */
	@Override
	public void updateEmployee(Employee emp) {
		
		entitymanager.merge(emp);
		entitymanager.flush();
	}


}














