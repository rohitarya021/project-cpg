package com.capgemini.services;

import java.util.List;

import com.capgemini.entities.Employee;

public interface EmployeeService {
	
	int addEmployee(Employee emp);

	List<Employee> getAllEmployee();
	
	 Employee getEmployeeById(int id);
	 
	 Employee getEmployeeByFirstName(String fname);
	
	void updateEmployee(Employee emp);
	
	/*	public List<Employee> showAllEmployees() ;
		
		public void modifyEmployee(Employee emp) ;
		
		public Employee searchEmployeeById(int id) ;
		
		public List<Employee> searchEmployeeByFirstName(String fname);
		
		public List<Employee> searchEmployeeByLasttName(String lname) ;
		
		public List<Employee> searchEmployeeByMartitalStatus(String marital);*/

}
